verifica a sorpresa 
